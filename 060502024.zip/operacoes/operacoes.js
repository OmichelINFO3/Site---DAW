window.onload = function(){
$(".botao-mais").click(function(){
    $(this).next(".div-mais").slideToggle();
})
}